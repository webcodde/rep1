<?php

/**
 * A Tribe__Events__Community__Captcha__Response is returned from Tribe__Events__Community__Captcha__Recaptcha::check_answer()
 */
class Tribe__Events__Community__Captcha__Response {
	public $is_valid;
	public $error;
}
