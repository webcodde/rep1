<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Community__PUE' );


	class TribeCommunityEvents_PUE extends Tribe__Events__Community__PUE {

	}