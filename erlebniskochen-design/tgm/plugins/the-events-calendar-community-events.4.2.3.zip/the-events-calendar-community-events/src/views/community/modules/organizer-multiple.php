<?php
/**
 * Multiple Organizers Template
 *
 * ### IMPORTANT ###
 * To Avoid code duplication this template lies on The Events Calendar
 * Path: the-events-calendar/src/admin-views/linked-post-section.php
 *
 * You should copy the contents of the file named above and follow the instructions below.
 *
 * Override this template in your own theme by creating a file at
 * [your-theme]/tribe-events/community/modules/organizer-multiple.php
 *
 * @package Tribe__Events__Community__Main
 * @since  4.1.1
 * @version 4.2
 * @author Modern Tribe Inc.
 *
 */
