<?php

class Tribe__Tickets_Plus__Meta__Field__Checkbox extends Tribe__Tickets_Plus__Meta__Field__Abstract_Options_Field {
	public $type = 'checkbox';

	public function save_value( $attendee_id, $field, $value ) {
	}
}
