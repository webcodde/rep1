<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Tickets_Plus__Commerce__Shopp__Main' );


	class TribeShoppTickets extends Tribe__Tickets_Plus__Commerce__Shopp__Main {

	}
