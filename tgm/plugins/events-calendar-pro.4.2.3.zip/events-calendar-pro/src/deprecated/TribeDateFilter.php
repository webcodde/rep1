<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__APM_Filters__Date_Filter' );


	class TribeDateFilter extends Tribe__Events__Pro__APM_Filters__Date_Filter {

	}